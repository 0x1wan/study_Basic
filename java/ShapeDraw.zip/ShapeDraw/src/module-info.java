/**
 * 
 */
/**
 * 
 */
module ShapeDraw {
}